// This file contains constants used across the application.

// URL for WhatsApp appointments, used in the Chatbot component.
export const WHATSAPP_APPOINTMENT_URL = "https://wa.me/5215512345678?text=Hola%2C%20vengo%20de%20Kontify%20Fiscal%20y%20me%20gustar%C3%ADa%20agendar%20una%20consulta.";